# 🧠 Brainiac — Your Web3 Second Brain

Never miss alpha. Never lose context. Your personal AI intelligence layer for Web3.

---

## What it does

- **Feed Intelligence** — Connect Discord & Telegram. AI surfaces signals, kills noise.
- **Wallet Memory** — Track wallets across chains. See every project you've touched.
- **Content Brain** — Generate threads, Space recaps, and alpha briefs from your feed.

---

## Stack

- **Frontend**: Next.js 14 + Tailwind CSS
- **AI**: Qwen API (via Dashscope)
- **Integrations**: Discord Bot + Telegram Bot
- **Storage**: 0G (decentralized, for hackathon)
- **Payments**: Stripe (add when ready)

---

## Setup on Replit

### 1. Install dependencies
```bash
npm install
```

### 2. Set environment variables
Copy `.env.example` to `.env.local` and fill in:
- `QWEN_API_KEY` — from [Dashscope](https://dashscope.console.aliyun.com/)
- `DISCORD_BOT_TOKEN` — from [Discord Developer Portal](https://discord.com/developers/applications)
- `TELEGRAM_BOT_TOKEN` — from @BotFather on Telegram

### 3. Run locally
```bash
npm run dev
```

### 4. Deploy on Replit
- Push to Replit
- Set env vars in Replit Secrets
- Run `npm run build && npm start`

---

## File structure

```
brainiac/
├── app/
│   ├── page.js              # Landing page
│   ├── dashboard/           # Main dashboard
│   ├── feed/                # Intelligence feed
│   ├── wallet/              # Wallet memory
│   └── brain/               # Content drafts
├── components/
│   └── Sidebar.jsx
├── lib/
│   ├── qwen.js              # Qwen AI calls
│   ├── discord.js           # Discord integration
│   └── telegram.js          # Telegram integration
└── styles/
    └── globals.css
```

---

## Pricing

| Plan | Price | Limits |
|------|-------|--------|
| Free | $0 | 1 wallet, 2 communities, 7-day history |
| Pro | $15/mo | 3 wallets, unlimited communities, 90-day history |
| Builder | $39/mo | Unlimited everything + API access |

---

## Hackathon: Zero Cup by 0G

Built for [The Zero Cup](https://0g.ai/arena/zero-cup) — submission deadline June 23, 2026.
Uses 0G for permanent decentralized storage of feed history and wallet data.
