'use client'
import Link from 'next/link'
import { Brain, Zap, Shield, TrendingUp, ArrowRight, MessageSquare, Wallet } from 'lucide-react'

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-[#0A0E1A] overflow-x-hidden">

      {/* Nav */}
      <nav className="flex items-center justify-between px-6 py-5 max-w-6xl mx-auto">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-indigo-500 flex items-center justify-center">
            <Brain size={16} className="text-white" />
          </div>
          <span className="font-display font-bold text-white text-lg tracking-tight">Brainiac</span>
        </div>
        <div className="flex items-center gap-3">
          <Link href="/dashboard" className="text-slate-400 text-sm hover:text-white transition-colors px-4 py-2">
            Sign in
          </Link>
          <Link href="/dashboard" className="bg-indigo-500 hover:bg-indigo-600 text-white text-sm font-medium px-4 py-2 rounded-lg transition-colors">
            Get started free
          </Link>
        </div>
      </nav>

      {/* Hero */}
      <section className="max-w-6xl mx-auto px-6 pt-20 pb-16 text-center">
        <div className="inline-flex items-center gap-2 bg-[#0F1629] border border-indigo-500/20 rounded-full px-4 py-1.5 mb-8">
          <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
          <span className="text-slate-400 text-xs font-medium">Powered by Qwen AI · Built on 0G Storage</span>
        </div>

        <h1 className="font-display font-bold text-5xl md:text-7xl text-white leading-[1.05] mb-6 tracking-tight">
          Your Web3 world,{' '}
          <span className="gradient-text">finally organized.</span>
        </h1>

        <p className="text-slate-400 text-lg md:text-xl max-w-2xl mx-auto mb-10 leading-relaxed">
          Brainiac pulls signal from your Discord servers and Telegram groups, remembers your on-chain activity, and helps you create content — all in one AI-powered dashboard.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
          <Link
            href="/dashboard"
            className="flex items-center gap-2 bg-indigo-500 hover:bg-indigo-600 text-white font-medium px-6 py-3 rounded-xl transition-all glow-indigo"
          >
            Start for free <ArrowRight size={16} />
          </Link>
          <Link
            href="/dashboard"
            className="flex items-center gap-2 text-slate-400 hover:text-white border border-slate-700 hover:border-slate-500 px-6 py-3 rounded-xl transition-all text-sm"
          >
            See how it works
          </Link>
        </div>
      </section>

      {/* Dashboard Preview */}
      <section className="max-w-5xl mx-auto px-6 mb-24">
        <div className="bg-[#0F1629] rounded-2xl border border-indigo-500/10 overflow-hidden">
          {/* Fake browser bar */}
          <div className="flex items-center gap-2 px-4 py-3 border-b border-white/5">
            <div className="w-3 h-3 rounded-full bg-[#1E2A47]" />
            <div className="w-3 h-3 rounded-full bg-[#1E2A47]" />
            <div className="w-3 h-3 rounded-full bg-[#1E2A47]" />
            <div className="flex-1 bg-[#151E38] rounded-md mx-4 py-1 px-3 text-xs text-slate-600">
              app.brainiac.xyz/dashboard
            </div>
          </div>
          {/* Mini dashboard preview */}
          <div className="flex h-64">
            {/* Sidebar preview */}
            <div className="w-44 border-r border-white/5 p-3 space-y-1">
              {['Dashboard', 'Feed', 'Wallets', 'Brain'].map((item, i) => (
                <div key={item} className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs ${i === 0 ? 'bg-indigo-500/20 text-white' : 'text-slate-500'}`}>
                  <div className={`w-1.5 h-1.5 rounded-full ${i === 0 ? 'bg-indigo-400' : 'bg-slate-600'}`} />
                  {item}
                </div>
              ))}
            </div>
            {/* Main preview */}
            <div className="flex-1 p-4 space-y-3">
              <div className="grid grid-cols-3 gap-3">
                {['12 new signals', '3 wallets tracked', '8 drafts ready'].map((label, i) => (
                  <div key={i} className="bg-[#151E38] rounded-lg p-3">
                    <div className="text-xs text-slate-500 mb-1">{label.split(' ').slice(1).join(' ')}</div>
                    <div className="font-display font-bold text-white text-lg">{label.split(' ')[0]}</div>
                  </div>
                ))}
              </div>
              <div className="space-y-2">
                {[
                  { src: 'Discord', msg: 'Alpha drop: New DEX launching on Base tomorrow...', time: '2m ago' },
                  { src: 'Telegram', msg: 'Whale wallet moved 500 ETH to Binance...', time: '11m ago' },
                  { src: 'Discord', msg: 'Community vote results: Proposal #14 passed...', time: '34m ago' },
                ].map((item, i) => (
                  <div key={i} className="flex items-start gap-3 bg-[#151E38] rounded-lg px-3 py-2">
                    <span className={`text-xs px-1.5 py-0.5 rounded font-medium ${item.src === 'Discord' ? 'bg-indigo-500/20 text-indigo-400' : 'bg-cyan-500/20 text-cyan-400'}`}>
                      {item.src}
                    </span>
                    <p className="text-xs text-slate-400 flex-1 truncate">{item.msg}</p>
                    <span className="text-xs text-slate-600 shrink-0">{item.time}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="max-w-6xl mx-auto px-6 pb-24">
        <div className="text-center mb-12">
          <h2 className="font-display font-bold text-3xl md:text-4xl text-white mb-3">
            Everything your Web3 brain needs
          </h2>
          <p className="text-slate-500 text-base max-w-xl mx-auto">Three tools. One dashboard. Zero noise.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-5">
          {[
            {
              icon: <Zap size={20} className="text-cyan-400" />,
              title: 'Feed Intelligence',
              desc: 'Connect Discord and Telegram. Brainiac reads every message so you don\'t have to — surfacing only what matters.',
              color: 'border-cyan-500/20 hover:border-cyan-500/40',
              bg: 'bg-cyan-500/5'
            },
            {
              icon: <Wallet size={20} className="text-indigo-400" />,
              title: 'Wallet Memory',
              desc: 'Every project you\'ve touched, tracked. Launches, rug pulls, active positions — your entire on-chain history, readable.',
              color: 'border-indigo-500/20 hover:border-indigo-500/40',
              bg: 'bg-indigo-500/5'
            },
            {
              icon: <MessageSquare size={20} className="text-purple-400" />,
              title: 'Content Brain',
              desc: 'Draft Space recaps, threads, and community updates. AI knows your history and writes in your voice.',
              color: 'border-purple-500/20 hover:border-purple-500/40',
              bg: 'bg-purple-500/5'
            }
          ].map((f) => (
            <div key={f.title} className={`${f.bg} border ${f.color} rounded-2xl p-6 transition-all`}>
              <div className="w-10 h-10 rounded-xl bg-[#0F1629] flex items-center justify-center mb-4">
                {f.icon}
              </div>
              <h3 className="font-display font-semibold text-white text-lg mb-2">{f.title}</h3>
              <p className="text-slate-500 text-sm leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Pricing */}
      <section className="max-w-6xl mx-auto px-6 pb-24">
        <div className="text-center mb-12">
          <h2 className="font-display font-bold text-3xl text-white mb-3">Simple pricing</h2>
          <p className="text-slate-500 text-base">Start free. Upgrade when you need more.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-5 max-w-4xl mx-auto">
          {[
            {
              name: 'Free',
              price: '$0',
              period: 'forever',
              features: ['1 wallet', '2 communities', '7-day history', '5 AI drafts/month'],
              cta: 'Start free',
              highlight: false
            },
            {
              name: 'Pro',
              price: '$15',
              period: '/month',
              features: ['3 wallets', 'Unlimited communities', '90-day history', 'Unlimited AI drafts'],
              cta: 'Get Pro',
              highlight: true
            },
            {
              name: 'Builder',
              price: '$39',
              period: '/month',
              features: ['Unlimited wallets', 'Unlimited communities', 'Full history', 'API access + team sharing'],
              cta: 'Go Builder',
              highlight: false
            }
          ].map((plan) => (
            <div
              key={plan.name}
              className={`rounded-2xl p-6 border ${plan.highlight
                ? 'bg-indigo-500/10 border-indigo-500/40 glow-indigo'
                : 'bg-[#0F1629] border-white/5'
              }`}
            >
              {plan.highlight && (
                <span className="text-xs font-medium text-indigo-400 bg-indigo-500/20 px-2 py-0.5 rounded-full mb-3 inline-block">
                  Most popular
                </span>
              )}
              <div className="mb-4">
                <span className="font-display font-bold text-white text-3xl">{plan.price}</span>
                <span className="text-slate-500 text-sm ml-1">{plan.period}</span>
              </div>
              <p className="font-display font-semibold text-white mb-4">{plan.name}</p>
              <ul className="space-y-2 mb-6">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-center gap-2 text-sm text-slate-400">
                    <div className="w-1 h-1 rounded-full bg-indigo-400 shrink-0" />
                    {f}
                  </li>
                ))}
              </ul>
              <Link
                href="/dashboard"
                className={`block text-center py-2.5 rounded-xl text-sm font-medium transition-colors ${plan.highlight
                  ? 'bg-indigo-500 hover:bg-indigo-600 text-white'
                  : 'border border-white/10 hover:border-white/20 text-slate-300 hover:text-white'
                }`}
              >
                {plan.cta}
              </Link>
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-white/5 px-6 py-8 max-w-6xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-md bg-indigo-500 flex items-center justify-center">
            <Brain size={12} className="text-white" />
          </div>
          <span className="text-slate-500 text-sm font-display font-medium">Brainiac</span>
        </div>
        <p className="text-slate-600 text-xs">© 2026 Brainiac. Built on 0G.</p>
      </footer>
    </div>
  )
}
