'use client'
import { useState } from 'react'
import { Zap, Wallet, MessageSquare, TrendingUp, ArrowRight, Plus, Bell } from 'lucide-react'
import Link from 'next/link'

const mockFeed = [
  { id: 1, source: 'Discord', server: 'Bankless DAO', msg: 'Alpha drop: New DEX launching on Base tomorrow with $200K liquidity incentives. Early LPs get 3x boost.', time: '2m ago', hot: true },
  { id: 2, source: 'Telegram', server: 'Crypto Signals', msg: 'Whale wallet 0x7f3a moved 500 ETH to Binance 20 mins ago. Keep watch on price action.', time: '11m ago', hot: true },
  { id: 3, source: 'Discord', server: 'Base Builders', msg: 'Community vote results are in: Proposal #14 passed with 78% approval. Treasury allocation confirmed.', time: '34m ago', hot: false },
  { id: 4, source: 'Telegram', server: 'NFT Alpha', msg: 'Floor on Pudgy Penguins up 12% in the last hour. Volume spike on Blur.', time: '1h ago', hot: false },
]

const mockWallets = [
  { address: '0x7f3a...9e2b', label: 'Main Wallet', chain: 'Ethereum', projects: 14, pnl: '+$2,340', positive: true },
  { address: '0xc91d...4f7a', label: 'Trading Wallet', chain: 'Base', projects: 7, pnl: '-$180', positive: false },
]

export default function Dashboard() {
  const [greeting] = useState(() => {
    const h = new Date().getHours()
    if (h < 12) return 'Good morning'
    if (h < 17) return 'Good afternoon'
    return 'Good evening'
  })

  return (
    <div className="p-6 max-w-5xl mx-auto animate-fade-in">

      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <p className="text-slate-500 text-sm mb-1">{greeting} 👋</p>
          <h1 className="font-display font-bold text-white text-2xl">Your Web3 Brain</h1>
        </div>
        <div className="flex items-center gap-3">
          <button className="relative w-9 h-9 bg-[#0F1629] border border-white/5 rounded-xl flex items-center justify-center text-slate-400 hover:text-white transition-colors">
            <Bell size={16} />
            <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-cyan-400 rounded-full" />
          </button>
          <Link href="/feed" className="flex items-center gap-2 bg-indigo-500 hover:bg-indigo-600 text-white text-sm font-medium px-4 py-2 rounded-xl transition-colors">
            <Plus size={14} /> Connect source
          </Link>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-8">
        {[
          { label: 'New signals', value: '12', sub: 'last 24h', icon: <Zap size={14} className="text-cyan-400" />, color: 'text-cyan-400' },
          { label: 'Communities', value: '4', sub: 'connected', icon: <MessageSquare size={14} className="text-indigo-400" />, color: 'text-indigo-400' },
          { label: 'Wallets', value: '2', sub: 'tracked', icon: <Wallet size={14} className="text-purple-400" />, color: 'text-purple-400' },
          { label: 'Drafts', value: '8', sub: 'AI-ready', icon: <TrendingUp size={14} className="text-green-400" />, color: 'text-green-400' },
        ].map((s) => (
          <div key={s.label} className="bg-[#0F1629] border border-white/5 rounded-2xl p-4 hover:border-white/10 transition-colors">
            <div className="flex items-center gap-1.5 mb-2">
              {s.icon}
              <span className="text-slate-500 text-xs">{s.label}</span>
            </div>
            <p className={`font-display font-bold text-2xl ${s.color}`}>{s.value}</p>
            <p className="text-slate-600 text-xs mt-0.5">{s.sub}</p>
          </div>
        ))}
      </div>

      <div className="grid md:grid-cols-3 gap-5">

        {/* Live Feed */}
        <div className="md:col-span-2 bg-[#0F1629] rounded-2xl border border-white/5 overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-white/5">
            <div className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
              <h2 className="font-display font-semibold text-white text-sm">Live Feed</h2>
            </div>
            <Link href="/feed" className="text-indigo-400 text-xs hover:text-indigo-300 flex items-center gap-1 transition-colors">
              View all <ArrowRight size={11} />
            </Link>
          </div>
          <div className="divide-y divide-white/5">
            {mockFeed.map((item) => (
              <div key={item.id} className="px-5 py-3.5 hover:bg-white/[0.02] transition-colors">
                <div className="flex items-center gap-2 mb-1.5">
                  <span className={`text-xs px-2 py-0.5 rounded-md font-medium ${
                    item.source === 'Discord'
                      ? 'bg-indigo-500/15 text-indigo-400'
                      : 'bg-cyan-500/15 text-cyan-400'
                  }`}>
                    {item.source}
                  </span>
                  <span className="text-slate-600 text-xs">{item.server}</span>
                  {item.hot && (
                    <span className="text-xs px-1.5 py-0.5 rounded-md bg-orange-500/15 text-orange-400 ml-auto">🔥 Hot</span>
                  )}
                  <span className={`text-slate-600 text-xs ${item.hot ? '' : 'ml-auto'}`}>{item.time}</span>
                </div>
                <p className="text-slate-400 text-sm leading-relaxed line-clamp-2">{item.msg}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Right column */}
        <div className="space-y-4">

          {/* Wallets */}
          <div className="bg-[#0F1629] rounded-2xl border border-white/5 overflow-hidden">
            <div className="flex items-center justify-between px-4 py-3.5 border-b border-white/5">
              <h2 className="font-display font-semibold text-white text-sm">Wallets</h2>
              <Link href="/wallet" className="text-indigo-400 text-xs hover:text-indigo-300 flex items-center gap-1 transition-colors">
                View <ArrowRight size={11} />
              </Link>
            </div>
            <div className="p-3 space-y-2">
              {mockWallets.map((w) => (
                <div key={w.address} className="bg-[#151E38] rounded-xl p-3">
                  <div className="flex items-start justify-between mb-1">
                    <p className="text-white text-xs font-medium">{w.label}</p>
                    <span className={`text-xs font-medium ${w.positive ? 'text-green-400' : 'text-red-400'}`}>{w.pnl}</span>
                  </div>
                  <p className="text-slate-600 text-xs font-mono">{w.address}</p>
                  <div className="flex items-center gap-2 mt-1.5">
                    <span className="text-xs text-slate-500 bg-[#1E2A47] px-1.5 py-0.5 rounded">{w.chain}</span>
                    <span className="text-xs text-slate-600">{w.projects} projects</span>
                  </div>
                </div>
              ))}
              <Link href="/wallet" className="flex items-center justify-center gap-1.5 text-slate-500 hover:text-slate-300 text-xs py-2 border border-dashed border-white/10 rounded-xl transition-colors">
                <Plus size={12} /> Add wallet
              </Link>
            </div>
          </div>

          {/* Quick Draft */}
          <div className="bg-[#0F1629] rounded-2xl border border-white/5 p-4">
            <h2 className="font-display font-semibold text-white text-sm mb-3">Quick Draft</h2>
            <p className="text-slate-500 text-xs mb-3 leading-relaxed">Let AI turn today's feed into a thread or Space recap.</p>
            <Link
              href="/brain"
              className="block text-center bg-indigo-500/10 hover:bg-indigo-500/20 border border-indigo-500/20 hover:border-indigo-500/40 text-indigo-400 text-sm font-medium py-2.5 rounded-xl transition-all"
            >
              Open Brain →
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
