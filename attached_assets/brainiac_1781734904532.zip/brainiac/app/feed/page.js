'use client'
import { useState } from 'react'
import { Plus, Search, Filter, RefreshCw, X, MessageSquare, Send } from 'lucide-react'

const SOURCES = ['All', 'Discord', 'Telegram']
const TAGS = ['All', 'Alpha', 'Whale Alert', 'Vote', 'Launch', 'NFT']

const mockFeed = [
  { id: 1, source: 'Discord', server: 'Bankless DAO', msg: 'Alpha drop: New DEX launching on Base tomorrow with $200K liquidity incentives. Early LPs get 3x boost. Contract will be deployed at 14:00 UTC.', time: '2m ago', tag: 'Alpha', hot: true },
  { id: 2, source: 'Telegram', server: 'Crypto Signals Pro', msg: 'Whale wallet 0x7f3a moved 500 ETH to Binance 20 mins ago. Keep watch on price action in the next hour. Pattern seen before recent dip.', time: '11m ago', tag: 'Whale Alert', hot: true },
  { id: 3, source: 'Discord', server: 'Base Builders', msg: 'Community vote results are in: Proposal #14 passed with 78% approval. Treasury allocation of 50K USDC confirmed for Q3 grants.', time: '34m ago', tag: 'Vote', hot: false },
  { id: 4, source: 'Telegram', server: 'NFT Alpha', msg: 'Floor on Pudgy Penguins up 12% in the last hour. Volume spike on Blur — 340 ETH traded in 60 minutes. Sentiment shift incoming?', time: '1h ago', tag: 'NFT', hot: false },
  { id: 5, source: 'Discord', server: 'DeFi Digest', msg: 'New yield strategy dropping on Arbitrum: 18% APY on stablecoin pairs via Camelot V4. Audited by Certik. Launching Thursday.', time: '2h ago', tag: 'Alpha', hot: false },
  { id: 6, source: 'Telegram', server: 'Layer Zero Insiders', msg: 'LayerZero airdrop snapshot confirmed. Must have at least 5 cross-chain transactions. Deadline is end of June.', time: '3h ago', tag: 'Launch', hot: true },
  { id: 7, source: 'Discord', server: 'NFT Hunters', msg: 'New mint alert: "ApeXplorer" by 0xMarcus dropping in 6 hours. Free mint + 0.01 ETH cover gas. 5000 supply. Allowlist open.', time: '4h ago', tag: 'NFT', hot: false },
  { id: 8, source: 'Telegram', server: 'Crypto Signals Pro', msg: 'SOL/BTC pair showing bullish divergence on 4H chart. Key resistance at $182. Break above could trigger 15% move.', time: '5h ago', tag: 'Alpha', hot: false },
]

function ConnectModal({ onClose }) {
  const [step, setStep] = useState(1)
  const [selected, setSelected] = useState(null)

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#0F1629] border border-white/10 rounded-2xl w-full max-w-md animate-slide-up">
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/5">
          <h3 className="font-display font-semibold text-white">Connect a community</h3>
          <button onClick={onClose} className="text-slate-500 hover:text-white transition-colors">
            <X size={18} />
          </button>
        </div>

        <div className="p-6">
          {step === 1 && (
            <div className="space-y-3">
              <p className="text-slate-500 text-sm mb-4">Choose where to pull signals from:</p>
              {[
                { id: 'discord', name: 'Discord Server', desc: 'Connect via webhook — no bot install needed', icon: '🟣', color: 'border-indigo-500/30 hover:border-indigo-500/60' },
                { id: 'telegram', name: 'Telegram Group', desc: 'Add our bot to any group or channel', icon: '🔵', color: 'border-cyan-500/30 hover:border-cyan-500/60' },
              ].map((opt) => (
                <button
                  key={opt.id}
                  onClick={() => { setSelected(opt.id); setStep(2) }}
                  className={`w-full flex items-center gap-4 p-4 bg-[#151E38] border ${opt.color} rounded-xl transition-all text-left`}
                >
                  <span className="text-2xl">{opt.icon}</span>
                  <div>
                    <p className="text-white text-sm font-medium">{opt.name}</p>
                    <p className="text-slate-500 text-xs mt-0.5">{opt.desc}</p>
                  </div>
                </button>
              ))}
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <p className="text-slate-500 text-sm">
                {selected === 'discord' ? 'Paste your Discord webhook URL:' : 'Add @BrainiacBot to your Telegram group, then paste the invite link:'}
              </p>
              <input
                type="text"
                placeholder={selected === 'discord' ? 'https://discord.com/api/webhooks/...' : 'https://t.me/...'}
                className="w-full bg-[#151E38] border border-white/10 rounded-xl px-4 py-3 text-white text-sm placeholder-slate-600 focus:outline-none focus:border-indigo-500/50"
              />
              <input
                type="text"
                placeholder="Give this community a name (e.g. Bankless DAO)"
                className="w-full bg-[#151E38] border border-white/10 rounded-xl px-4 py-3 text-white text-sm placeholder-slate-600 focus:outline-none focus:border-indigo-500/50"
              />
              <div className="flex gap-3">
                <button onClick={() => setStep(1)} className="flex-1 py-3 border border-white/10 text-slate-400 rounded-xl text-sm hover:border-white/20 transition-colors">
                  Back
                </button>
                <button onClick={onClose} className="flex-1 py-3 bg-indigo-500 hover:bg-indigo-600 text-white rounded-xl text-sm font-medium transition-colors">
                  Connect
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default function FeedPage() {
  const [activeSource, setActiveSource] = useState('All')
  const [activeTag, setActiveTag] = useState('All')
  const [search, setSearch] = useState('')
  const [showModal, setShowModal] = useState(false)

  const filtered = mockFeed.filter(item => {
    const matchSource = activeSource === 'All' || item.source === activeSource
    const matchTag = activeTag === 'All' || item.tag === activeTag
    const matchSearch = !search || item.msg.toLowerCase().includes(search.toLowerCase()) || item.server.toLowerCase().includes(search.toLowerCase())
    return matchSource && matchTag && matchSearch
  })

  return (
    <div className="p-6 max-w-4xl mx-auto animate-fade-in">
      {showModal && <ConnectModal onClose={() => setShowModal(false)} />}

      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="font-display font-bold text-white text-2xl">Feed Intelligence</h1>
          <p className="text-slate-500 text-sm mt-0.5">Signal from your communities, filtered by AI</p>
        </div>
        <div className="flex items-center gap-2">
          <button className="w-9 h-9 bg-[#0F1629] border border-white/5 rounded-xl flex items-center justify-center text-slate-400 hover:text-white transition-colors">
            <RefreshCw size={15} />
          </button>
          <button
            onClick={() => setShowModal(true)}
            className="flex items-center gap-2 bg-indigo-500 hover:bg-indigo-600 text-white text-sm font-medium px-4 py-2 rounded-xl transition-colors"
          >
            <Plus size={14} /> Connect
          </button>
        </div>
      </div>

      {/* Connected sources */}
      <div className="grid grid-cols-2 gap-3 mb-6">
        {[
          { name: 'Bankless DAO', source: 'Discord', status: 'live', count: '47 today' },
          { name: 'Crypto Signals Pro', source: 'Telegram', status: 'live', count: '23 today' },
          { name: 'Base Builders', source: 'Discord', status: 'live', count: '15 today' },
          { name: 'NFT Alpha', source: 'Telegram', status: 'live', count: '8 today' },
        ].map((src) => (
          <div key={src.name} className="flex items-center gap-3 bg-[#0F1629] border border-white/5 rounded-xl px-3 py-2.5">
            <div className={`w-2 h-2 rounded-full ${src.status === 'live' ? 'bg-green-400 animate-pulse' : 'bg-slate-600'}`} />
            <div className="flex-1 min-w-0">
              <p className="text-white text-xs font-medium truncate">{src.name}</p>
              <p className="text-slate-600 text-xs">{src.count}</p>
            </div>
            <span className={`text-xs px-1.5 py-0.5 rounded ${src.source === 'Discord' ? 'bg-indigo-500/15 text-indigo-400' : 'bg-cyan-500/15 text-cyan-400'}`}>
              {src.source}
            </span>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3 mb-5">
        <div className="flex items-center gap-1.5 bg-[#0F1629] border border-white/5 rounded-xl px-3 py-2">
          <Search size={13} className="text-slate-500" />
          <input
            type="text"
            placeholder="Search signals..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="bg-transparent text-white text-sm placeholder-slate-600 focus:outline-none w-40"
          />
        </div>

        <div className="flex items-center gap-1.5">
          {SOURCES.map(s => (
            <button
              key={s}
              onClick={() => setActiveSource(s)}
              className={`text-xs px-3 py-1.5 rounded-lg transition-colors ${activeSource === s ? 'bg-indigo-500/20 text-indigo-400 border border-indigo-500/30' : 'text-slate-500 hover:text-slate-300 border border-transparent'}`}
            >
              {s}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-1.5 ml-auto">
          {TAGS.map(t => (
            <button
              key={t}
              onClick={() => setActiveTag(t)}
              className={`text-xs px-3 py-1.5 rounded-lg transition-colors ${activeTag === t ? 'bg-white/10 text-white' : 'text-slate-500 hover:text-slate-300'}`}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* Feed */}
      <div className="space-y-2">
        {filtered.map((item) => (
          <div key={item.id} className="bg-[#0F1629] border border-white/5 hover:border-white/10 rounded-2xl p-4 transition-all group">
            <div className="flex items-center gap-2 mb-2">
              <span className={`text-xs px-2 py-0.5 rounded-md font-medium ${item.source === 'Discord' ? 'bg-indigo-500/15 text-indigo-400' : 'bg-cyan-500/15 text-cyan-400'}`}>
                {item.source}
              </span>
              <span className="text-slate-500 text-xs">{item.server}</span>
              <span className="text-xs px-2 py-0.5 rounded-md bg-[#151E38] text-slate-500 ml-1">{item.tag}</span>
              {item.hot && <span className="text-xs text-orange-400">🔥</span>}
              <span className="text-slate-600 text-xs ml-auto">{item.time}</span>
            </div>
            <p className="text-slate-300 text-sm leading-relaxed">{item.msg}</p>
            <div className="flex items-center gap-2 mt-3 opacity-0 group-hover:opacity-100 transition-opacity">
              <button className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1 transition-colors">
                <MessageSquare size={11} /> Draft from this
              </button>
              <button className="text-xs text-slate-500 hover:text-slate-300 flex items-center gap-1 transition-colors ml-auto">
                <Send size={11} /> Share
              </button>
            </div>
          </div>
        ))}

        {filtered.length === 0 && (
          <div className="text-center py-16">
            <div className="w-12 h-12 bg-[#0F1629] rounded-2xl flex items-center justify-center mx-auto mb-3">
              <Filter size={20} className="text-slate-600" />
            </div>
            <p className="text-slate-500 text-sm">No signals match your filters.</p>
            <button onClick={() => { setActiveSource('All'); setActiveTag('All'); setSearch('') }} className="text-indigo-400 text-xs mt-1 hover:text-indigo-300 transition-colors">
              Clear filters
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
