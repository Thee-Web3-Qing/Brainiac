import Sidebar from '../../components/Sidebar'

export default function FeedLayout({ children }) {
  return (
    <div className="flex min-h-screen bg-[#0A0E1A]">
      <Sidebar />
      <main className="flex-1 ml-56 min-h-screen">
        {children}
      </main>
    </div>
  )
}
