'use client'
import { useState } from 'react'
import { Wand2, Copy, Check, RefreshCw, ChevronDown, FileText, Twitter, Mic, MessageSquare } from 'lucide-react'

const DRAFT_TYPES = [
  { id: 'thread', label: 'X Thread', icon: <Twitter size={14} />, desc: 'Turn feed signals into a Twitter thread' },
  { id: 'recap', label: 'Space Recap', icon: <Mic size={14} />, desc: 'Summarize a Space you hosted' },
  { id: 'update', label: 'Community Update', icon: <MessageSquare size={14} />, desc: 'Weekly digest for your community' },
  { id: 'brief', label: 'Alpha Brief', icon: <FileText size={14} />, desc: 'Curated alpha report from your feed' },
]

const mockDrafts = [
  {
    id: 1,
    type: 'X Thread',
    title: 'Alpha thread — June 17',
    preview: '🧵 Biggest signals from Web3 this week that most people missed...',
    created: '2h ago',
  },
  {
    id: 2,
    type: 'Space Recap',
    title: 'Recap: DeFi 2025 with Bankless',
    preview: "Yesterday's Space with @bankless covered 3 key narratives shaping DeFi this summer...",
    created: '1d ago',
  },
  {
    id: 3,
    type: 'Alpha Brief',
    title: 'Weekly Alpha Brief #12',
    preview: '📡 This week: Base DEX launch, LayerZero snapshot, and whale moves to watch...',
    created: '3d ago',
  },
]

function CopyBtn({ text }) {
  const [copied, setCopied] = useState(false)
  return (
    <button
      onClick={() => { navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 2000) }}
      className="flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-300 transition-colors"
    >
      {copied ? <><Check size={12} className="text-green-400" /> Copied</> : <><Copy size={12} /> Copy</>}
    </button>
  )
}

export default function BrainPage() {
  const [selectedType, setSelectedType] = useState(DRAFT_TYPES[0])
  const [prompt, setPrompt] = useState('')
  const [loading, setLoading] = useState(false)
  const [draft, setDraft] = useState(null)
  const [showTypeMenu, setShowTypeMenu] = useState(false)

  const generateDraft = async () => {
    if (!prompt.trim()) return
    setLoading(true)
    setDraft(null)

    const systemPrompt = `You are Brainiac, an AI writing assistant for Web3 creators and community builders.
Your job is to help users create engaging Web3 content in their voice — confident, informed, no fluff.
For X threads: write punchy, numbered tweets. For Space recaps: write a narrative summary with key highlights.
For community updates: write a friendly weekly digest. For alpha briefs: write a sharp, curated signal report.
Keep the tone knowledgeable but accessible. Use emojis sparingly. No corporate speak.`

    const userMsg = `Create a ${selectedType.label} about: ${prompt}

Context from my Web3 feed today:
- Alpha drop: New DEX launching on Base with $200K liquidity incentives
- Whale moved 500 ETH to Binance (possible sell pressure)
- LayerZero airdrop snapshot confirmed — deadline end of June
- Pudgy Penguins floor up 12% with Blur volume spike

Write the full ${selectedType.label} now.`

    try {
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-6',
          max_tokens: 1000,
          system: systemPrompt,
          messages: [{ role: 'user', content: userMsg }]
        })
      })
      const data = await res.json()
      const text = data.content?.map(b => b.text || '').join('') || 'Could not generate draft. Try again.'
      setDraft(text)
    } catch (err) {
      setDraft('Error connecting to AI. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="p-6 max-w-4xl mx-auto animate-fade-in">

      {/* Header */}
      <div className="mb-6">
        <h1 className="font-display font-bold text-white text-2xl">Content Brain</h1>
        <p className="text-slate-500 text-sm mt-0.5">Turn your feed into content that hits</p>
      </div>

      <div className="grid md:grid-cols-3 gap-5">

        {/* Generator */}
        <div className="md:col-span-2 space-y-4">

          {/* Type selector */}
          <div className="relative">
            <button
              onClick={() => setShowTypeMenu(!showTypeMenu)}
              className="w-full flex items-center justify-between bg-[#0F1629] border border-white/10 rounded-xl px-4 py-3 text-left transition-colors hover:border-white/20"
            >
              <div className="flex items-center gap-3">
                <span className="text-indigo-400">{selectedType.icon}</span>
                <div>
                  <p className="text-white text-sm font-medium">{selectedType.label}</p>
                  <p className="text-slate-500 text-xs">{selectedType.desc}</p>
                </div>
              </div>
              <ChevronDown size={15} className={`text-slate-500 transition-transform ${showTypeMenu ? 'rotate-180' : ''}`} />
            </button>

            {showTypeMenu && (
              <div className="absolute top-full left-0 right-0 mt-1 bg-[#0F1629] border border-white/10 rounded-xl overflow-hidden z-10 animate-slide-up">
                {DRAFT_TYPES.map((type) => (
                  <button
                    key={type.id}
                    onClick={() => { setSelectedType(type); setShowTypeMenu(false) }}
                    className={`w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-white/5 transition-colors ${type.id === selectedType.id ? 'bg-indigo-500/10' : ''}`}
                  >
                    <span className="text-indigo-400">{type.icon}</span>
                    <div>
                      <p className="text-white text-sm">{type.label}</p>
                      <p className="text-slate-500 text-xs">{type.desc}</p>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Prompt */}
          <div className="bg-[#0F1629] border border-white/10 rounded-xl overflow-hidden focus-within:border-indigo-500/40 transition-colors">
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder={`What should this ${selectedType.label} be about? e.g. "The Base DEX launch and what it means for LPs"`}
              className="w-full bg-transparent px-4 py-3 text-white text-sm placeholder-slate-600 focus:outline-none resize-none min-h-[100px] leading-relaxed"
              rows={4}
            />
            <div className="flex items-center justify-between px-4 py-2.5 border-t border-white/5">
              <p className="text-slate-600 text-xs">AI will use your connected feed as context</p>
              <button
                onClick={generateDraft}
                disabled={loading || !prompt.trim()}
                className="flex items-center gap-2 bg-indigo-500 hover:bg-indigo-600 disabled:opacity-40 disabled:cursor-not-allowed text-white text-sm font-medium px-4 py-2 rounded-lg transition-colors"
              >
                {loading ? <RefreshCw size={13} className="animate-spin" /> : <Wand2 size={13} />}
                {loading ? 'Writing...' : 'Generate'}
              </button>
            </div>
          </div>

          {/* Output */}
          {loading && (
            <div className="bg-[#0F1629] border border-white/5 rounded-xl p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-2 h-2 rounded-full bg-indigo-400 animate-pulse" />
                <span className="text-slate-500 text-sm">Brainiac is writing...</span>
              </div>
              <div className="space-y-2">
                {[80, 60, 90, 50, 70].map((w, i) => (
                  <div key={i} className={`h-3 bg-[#151E38] rounded animate-pulse`} style={{ width: `${w}%` }} />
                ))}
              </div>
            </div>
          )}

          {draft && !loading && (
            <div className="bg-[#0F1629] border border-indigo-500/20 rounded-xl overflow-hidden animate-slide-up">
              <div className="flex items-center justify-between px-4 py-3 border-b border-white/5">
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-green-400" />
                  <span className="text-white text-sm font-medium">Draft ready</span>
                  <span className="text-slate-500 text-xs">· {selectedType.label}</span>
                </div>
                <div className="flex items-center gap-3">
                  <CopyBtn text={draft} />
                  <button
                    onClick={generateDraft}
                    className="flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-300 transition-colors"
                  >
                    <RefreshCw size={12} /> Regenerate
                  </button>
                </div>
              </div>
              <div className="p-4">
                <pre className="text-slate-300 text-sm leading-relaxed whitespace-pre-wrap font-body">{draft}</pre>
              </div>
            </div>
          )}
        </div>

        {/* Saved drafts */}
        <div>
          <h2 className="font-display font-semibold text-white text-sm mb-3">Recent drafts</h2>
          <div className="space-y-2">
            {mockDrafts.map((d) => (
              <div key={d.id} className="bg-[#0F1629] border border-white/5 hover:border-white/10 rounded-xl p-3.5 cursor-pointer transition-all group">
                <div className="flex items-center gap-2 mb-1.5">
                  <span className="text-xs text-indigo-400 bg-indigo-500/10 px-1.5 py-0.5 rounded">{d.type}</span>
                  <span className="text-slate-600 text-xs ml-auto">{d.created}</span>
                </div>
                <p className="text-white text-xs font-medium mb-1 leading-snug">{d.title}</p>
                <p className="text-slate-500 text-xs leading-relaxed line-clamp-2">{d.preview}</p>
              </div>
            ))}
          </div>

          {/* Tips */}
          <div className="mt-4 bg-indigo-500/5 border border-indigo-500/15 rounded-xl p-4">
            <p className="text-indigo-400 text-xs font-medium mb-2">💡 Pro tip</p>
            <p className="text-slate-500 text-xs leading-relaxed">
              Connect more communities for richer context. The more feed Brainiac has, the better your drafts get.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
