'use client'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Brain, LayoutDashboard, Zap, Wallet, MessageSquare, Settings, ChevronRight } from 'lucide-react'

const navItems = [
  { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/feed', label: 'Feed', icon: Zap },
  { href: '/wallet', label: 'Wallets', icon: Wallet },
  { href: '/brain', label: 'Brain', icon: MessageSquare },
]

export default function Sidebar() {
  const pathname = usePathname()

  return (
    <aside className="w-56 min-h-screen bg-[#0A0E1A] border-r border-white/5 flex flex-col fixed left-0 top-0 z-30">
      {/* Logo */}
      <div className="px-5 py-5 border-b border-white/5">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-indigo-500 flex items-center justify-center shrink-0">
            <Brain size={15} className="text-white" />
          </div>
          <div>
            <p className="font-display font-bold text-white text-sm leading-none">Brainiac</p>
            <p className="text-slate-600 text-xs mt-0.5">Web3 Second Brain</p>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-0.5">
        {navItems.map(({ href, label, icon: Icon }) => {
          const active = pathname === href
          return (
            <Link
              key={href}
              href={href}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-all group ${
                active
                  ? 'bg-indigo-500/15 text-white border-l-2 border-indigo-500'
                  : 'text-slate-500 hover:text-slate-300 hover:bg-white/5'
              }`}
            >
              <Icon size={16} className={active ? 'text-indigo-400' : 'text-slate-600 group-hover:text-slate-400'} />
              <span className={active ? 'font-medium' : ''}>{label}</span>
              {active && <ChevronRight size={12} className="ml-auto text-indigo-400/60" />}
            </Link>
          )
        })}
      </nav>

      {/* User section */}
      <div className="px-3 pb-4 border-t border-white/5 pt-4">
        <Link href="/settings" className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-slate-500 hover:text-slate-300 hover:bg-white/5 transition-all text-sm">
          <Settings size={16} className="text-slate-600" />
          Settings
        </Link>
        <div className="mt-3 px-3 py-3 bg-[#0F1629] rounded-xl border border-white/5">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-full bg-gradient-to-br from-indigo-500 to-cyan-500 flex items-center justify-center text-xs font-bold text-white">
              G
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-white text-xs font-medium truncate">Giwa Sheedah</p>
              <p className="text-slate-600 text-xs truncate">Free plan</p>
            </div>
          </div>
        </div>
      </div>
    </aside>
  )
}
